import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Random;


public class dbConnection {
	/*Statements below used to connect to database and execute queries throughout the class */
	private static final String dBaseURL = "jdbc:derby:C:\\Users\\Selecao12\\MyDB;create=true;user=Fred;password=tom@t0";
	private static Connection conn = null;
	private static Statement stmt = null;
	/*Variables accessible to the GUI. Done to save time*/
	public int totalFrameCount = 0;
	public int actionTotalFrames = 0;
	public int actionFramesComp = 0;
	public Date deadline;
	/*Arrays containing values to be populated in table. Values for deadline and the various frame counts were done with
	 * random number generators.*/
	private String[] c_names = {"Ryu", "Ken", "Chun Li", "Guile", "Blanka", "E. Honda", "Dhalsim", "Zangief"};
	private String[] a_lName = {"Hu", "Ross", "Wong", "James", "Sheridan"};
	private String[] a_fName = {"Chris", "Mike", "Justin", "Kevin", "Bryan"};
	private String[] s_actions = {"S_LP", "S_MP", "S_HP", "S_LK", "S_MK", "S_HK", "S_IDLE", "S_FWD", "S_BCK", "S_THRW"};
	private String[] j_actions = {"J_LP", "J_MP", "J_HP", "J_LK", "J_MK", "J_HK", "J_NEUTRAL", "J_FWD", "J_BCK"};
	private String[] c_actions = {"C_LP", "C_MP", "C_HP", "C_LK", "C_MK", "C_HK", "C_IDLE", "C_TRANS"};
	private String[] m_actions = {"BLK_STUN", "HIT_STUN", "J_HIT_STUN", "DIZZY", "WIN_POSE", "LOSE_POSE", "KNOCKDOWN"};
	private String[] sig_actionsRyu = {"HADOUKEN", "SHORYUKEN", "TATSUMAKI SEMPUKYAKU"};
	private String[] sig_actionsKen = {"HADOUKEN", "SHORYUKEN", "TATSUMAKI SEMPUKYAKU"};
	private String[] sig_actionsChunLi = {"LIGHTNING LEGS", "SPINNING BIRD KICK", "HEAD STOMP", "OVERHEAD KICK", "AIR THRW"};
	private String[] sig_actionsGuile = {"SONIC BOOM", "FLASH KICK", "AIR THRW"};
	private String[] sig_actionsBlanka = {"BALL", "ELECTRIC ATTACK"};
	private String[] sig_actionsEHonda = {"SUMO HEADBUTT", "HUNDRED HAND SLAP", "SUMO DROP"};
	private String[] sig_actionsDhalsim = {"YOGA FIRE", "YOGA FLAME", "YOGA DRILL(HEAD)", "YOGA DRILL (FEET)"};
	private String[] sig_actionsZangief = {"SPINNING PILE DRIVER", "LARIAT"};
	/*Variables used to keep track of and properly calculate frame data*/
	private int totFrmCnt = 0;
	private int totFrmComp = 0;
	private int actTotFrm = 0;
	private int actFrmComp = 0;
	

	
	public dbConnection() { //Constructor 
		connectToDB();
		initializeTable();
	}
	
	private void connectToDB() { //Connects to Database using Derby's Embedded Driver and the pathname declared above
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
			conn = DriverManager.getConnection(dBaseURL);
			
		} catch(Exception e) {
			e.printStackTrace();
			closeConnection();
		}
	}
	
	private void initializeTable() {
		/*Populates the table with the initial values. If values already exist, nothing is performed*/
		try {
			Random rand = new Random();
			Calendar cal = Calendar.getInstance();
			int artistid;
			int charid;
			stmt = conn.createStatement();
			ResultSet rslts = stmt.executeQuery("SELECT actions FROM Actions");
			if (rslts.next()) { }
			else {
				try {
					rslts = stmt.executeQuery("SELECT * FROM Artist");
					if (!rslts.next()) {
						for(int i = 0; i < a_lName.length; i++) {
							artistid = i + 41;												
							stmt.execute("INSERT INTO Artist VALUES ('" + a_lName[i] + "', '" + a_fName[i] + "', " 
									+ artistid + ")");
						}
					}
					rslts = stmt.executeQuery("SELECT * FROM Characters");
					if (!rslts.next()) {
						for (int i = 0; i < c_names.length; i++) {
							stmt.execute("INSERT INTO Characters VALUES ('" + c_names[i] + "', " + (i + 1) + ", " 
									+ totFrmComp + ", " + totFrmCnt + ")");							
						}
					}
					for (int i = 0; i < c_names.length ; i++) { //array.length = to final index + 1
						charid = i + 1;
						totFrmComp = 0;
						totFrmCnt = 0;
						for (int j = 0; j < s_actions.length; j++) {
							artistid = rand.nextInt(5) + 41;
							actTotFrm = rand.nextInt(11) + 4;
							actFrmComp = actTotFrm - rand.nextInt(3);
							totFrmComp += actFrmComp;
							totFrmCnt += actTotFrm;
							cal.clear();
							cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
							deadline = new Date(cal.getTimeInMillis());
							
							stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
									+ artistid + ", 'STANDING', '" + s_actions[j] 
											+ "', " + actFrmComp + ", " + actTotFrm
											+ ", '" + deadline.toString() + "')");
						}
						for (int j = 0; j < c_actions.length; j++) {
							artistid = rand.nextInt(5) + 41;
							actTotFrm = rand.nextInt(11) + 4;
							actFrmComp = actTotFrm - rand.nextInt(3);
							totFrmComp += actFrmComp;
							totFrmCnt += actTotFrm;
							cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
							deadline = new Date(cal.getTimeInMillis());
							
							stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
									+ Integer.toString(artistid) + ", 'CROUCHING', '" + c_actions[j] 
											+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
											+ ", '" + deadline.toString() + "')");
						}
						for (int j = 0; j < j_actions.length; j++) {
							artistid = rand.nextInt(5) + 41;
							actTotFrm = rand.nextInt(11) + 4;
							actFrmComp = actTotFrm - rand.nextInt(3);
							totFrmComp += actFrmComp;
							totFrmCnt += actTotFrm;
							cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
							
							deadline = new Date(cal.getTimeInMillis());
							
							stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
									+ Integer.toString(artistid) + ", 'JUMPING', '" + j_actions[j] 
											+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
											+ ", '" + deadline.toString() + "')");
						}
						for (int j = 0; j < m_actions.length; j++) {
							artistid = rand.nextInt(5) + 41;
							actTotFrm = rand.nextInt(11) + 4;
							actFrmComp = actTotFrm - rand.nextInt(3);
							totFrmComp += actFrmComp;
							totFrmCnt += actTotFrm;
							cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
							deadline = new Date(cal.getTimeInMillis());
							
							stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
									+ Integer.toString(artistid) + ", 'MISC', '" + m_actions[j] 
											+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
											+ ", '" + deadline.toString() + "')");
						}
						switch (charid) {
						case 1: //Ryu
							for (int j = 0; j < sig_actionsRyu.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsRyu[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 2: //Ken
							for (int j = 0; j < sig_actionsKen.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsKen[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 3: //ChunLi
							for (int j = 0; j < sig_actionsChunLi.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsChunLi[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 4: //Guile
							for (int j = 0; j < sig_actionsGuile.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsGuile[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 5: //Blanka
							for (int j = 0; j < sig_actionsBlanka.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsBlanka[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 6: //EHonda
							for (int j = 0; j < sig_actionsEHonda.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsEHonda[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 7: //Dhalsim
							for (int j = 0; j < sig_actionsDhalsim.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsDhalsim[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						case 8: //Zangief
							for (int j = 0; j < sig_actionsZangief.length; j++) {
								artistid = rand.nextInt(5) + 41;
								actTotFrm = rand.nextInt(11) + 4;
								actFrmComp = actTotFrm - rand.nextInt(3);
								totFrmComp += actFrmComp;
								totFrmCnt += actTotFrm;
								cal.set(2013, cal.MAY, rand.nextInt(31) + 1);
								deadline = new Date(cal.getTimeInMillis());
								
								stmt.execute("INSERT INTO Actions VALUES (" + Integer.toString(charid) + ", " 
										+ Integer.toString(artistid) + ", 'SIGNATURE', '" + sig_actionsZangief[j] 
												+ "', " + Integer.toString(actFrmComp) + ", " + Integer.toString(actTotFrm)
												+ ", '" + deadline.toString() + "')");
							}
							break;
						default:
							break;
						}
						stmt.execute("UPDATE Characters SET TotalFrameCount = " + totFrmCnt + ", TotalFramesComp= " + 
						totFrmComp + " WHERE charId = " + charid);						
					}
					/**/					
				} catch (SQLException e) {
					e.printStackTrace();
			}
			}
			
			rslts.close();
			stmt.close();
		} catch(Exception e) {
			e.printStackTrace();
			closeConnection();
		}
	}
	
	public String[] getActions(String typeAction, int artistid) {
		/*Retreives the specific actions worked on by a certain artist and part of a specific category of actions*/
		String[] actionList = {"", "", "", "", "", "", "", "", "", "", ""}; 
		try {
		stmt = conn.createStatement();
		ResultSet rslts = stmt.executeQuery("SELECT DISTINCT actions FROM Actions WHERE typeAction = '" + typeAction + "' AND artistID = "
				+ Integer.toString(artistid) + ""); 
		
		int i = 0;
		while(rslts.next()) {
			actionList[i] = rslts.getString(1);
			i++;
			
		}
		rslts.close();
		stmt.close();
		
		
	} catch(SQLException e) {
		e.printStackTrace();
		closeConnection();
	}
		return actionList;
	}
	
	public void addArtist(String lname, String fname) {
		/*Adds a new artist to the project. Currently only reflected in the database.*/
		try{
			int artistid;
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rslts = stmt.executeQuery("SELECT artistid FROM Artist");
			rslts.last();
			artistid = rslts.getInt(1) + 1;
			stmt.execute("INSERT INTO Artist VALUES ('" + lname + "', '" + fname + "', " + artistid + ")");
			rslts.close();
			stmt.close();			
		}catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
		}
	}
	
	public void removeArtist() {
		/*Pending implementation*/
	}
	
	public void newJob(int artistid, String typeAction, String action, int charid, int totFrm, Date dline) {
		/*Adds a new job where the user assigns an artist and specifies the new action to be worked on and all the data
		 * associated with that new action (frames, deadline, type, etc.)*/
		try {
			int newTotal;
			stmt = conn.createStatement();
			ResultSet rslts = stmt.executeQuery("SELECT TotalFrameCount FROM Characters WHERE charid = " + charid);
			newTotal = rslts.getInt(1) + totFrm;
			stmt.execute("UPDATE Characters SET TotalFrameCount= " + newTotal);
			stmt.execute("INSERT INTO Actions VALUES (" + charid + ", " + artistid + ", '" + typeAction + "', '" 
			+ action + "', " + 0 /*Frames completed*/ + ", " + totFrm + ", '" + dline.toString() + "')");
			
			rslts.close();
			stmt.close();			
		} catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
			
		}
	}
	
	public String[] getArtists(int charID) {
		/*Retrieves a list of artists who are working on the selected character*/
		String[] artistList = {"", "", "", "", "", "", ""};
		int[] idList = {0, 0, 0, 0, 0, 0, 0, 0};
		try {
			stmt = conn.createStatement();
			ResultSet rslts = stmt.executeQuery("SELECT DISTINCT artistID FROM Actions WHERE charID = " 
			+ Integer.toString(charID) + " ORDER BY artistId");
			int i = 0;
			while(rslts.next()) {
				idList[i] = rslts.getInt(1);
				i++;
			}
			int j = 0;
			boolean rowExists;
			do {
				rslts = stmt.executeQuery("SELECT DISTINCT firstname, lastname FROM Artist WHERE artistId = " + idList[j]);
				rowExists = rslts.next();
				if(rowExists) {
					artistList[j] = rslts.getString(1) + " " + rslts.getString(2);
					j++;
				}
			} while(rowExists);
			rslts.close();
			stmt.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
		}
		
		return artistList;
	}
	
	public String[] getTypeActions(int artistID) {
		/*Retrieves the type of actions currently worked on by the selected artist*/
		String[] typeList = {"", "", "", "", ""};
		
		try {
			stmt = conn.createStatement();
			ResultSet rslts = stmt.executeQuery("SELECT DISTINCT typeAction FROM Actions WHERE artistID = " 
			+ Integer.toString(artistID) + "");
			int i = 0;
			while(rslts.next()) {
				typeList[i] = rslts.getString(1);
				i++;
			}
			
			rslts.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
		}
		
		return typeList;
	}
	
	public void updateTotalFrames(int charID) {
		/*Updates the totalFrameCount field so that the most current data is displayed in the GUI's label*/
		try {
			stmt = conn.createStatement();
			ResultSet rslts = stmt.executeQuery("SELECT totalFrameCount FROM Characters WHERE charID = " 
			+ Integer.toString(charID) + "");
			rslts.next();
			totalFrameCount = rslts.getInt(1);
			rslts.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
		}
	}
	
	public void actionFrameData(int charID, String action) {
		try {
			/*Updates the frame data fields and deadline field so that their reference are up to date 
			 * on the GUI*/
			Calendar cal = Calendar.getInstance();
			stmt = conn.createStatement();
			System.out.println(action);
			ResultSet rslts = stmt.executeQuery("SELECT totalFrames, framesComp, deadline FROM Actions WHERE actions = '" 
			+ action + "' AND charID = " + Integer.toString(charID) + "");
			rslts.next();
			actionTotalFrames = rslts.getInt(1);
			actionFramesComp = rslts.getInt(2);
			cal.setTime(rslts.getDate(3));
			deadline = new Date(cal.getTimeInMillis());
			
		} catch (SQLException e) {
			e.printStackTrace();
			closeConnection();
		}
	}
	
	public void closeConnection() {
		/*Closes connection.*/
		try {
			if(stmt != null) { stmt.close(); }
			if(conn != null) {conn.close(); }
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
