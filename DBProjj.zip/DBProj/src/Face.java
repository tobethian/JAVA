import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Face extends JFrame {	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel charsName;
	private JLabel deadline;
	private JLabel framesComp;
	private JLabel totalFrameCount;
	private JComboBox artistSelect;
	private JComboBox actionTypeSelect;
	private JComboBox actionSelect;
	private dbConnection connect;
	private String fname;
	private String lname;
	private int artistid;
	private int charid;
	private String typeAction;
	private JDialog dialog;
	private static Face frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Face();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	}

	/**
	 * Create the frame.
	 */
	public Face() {
		setTitle("Street Fighter II - Asset Manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 829, 600);
		connect = new dbConnection();
		
		
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Character");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmRyu = new JMenuItem("Ryu");
		mntmRyu.addActionListener(new MenuListener());
		mnNewMenu.add(mntmRyu);
		
		JMenuItem mntmKen = new JMenuItem("Ken");
		mntmKen.addActionListener(new MenuListener());
		mnNewMenu.add(mntmKen);
		
		JMenuItem mntmChunLi = new JMenuItem("Chun li");
		mntmChunLi.addActionListener(new MenuListener());
		mnNewMenu.add(mntmChunLi);
		
		JMenuItem mntmGuile = new JMenuItem("Guile");
		mntmGuile.addActionListener(new MenuListener());
		mnNewMenu.add(mntmGuile);
				
		JMenuItem mntmBlanka = new JMenuItem("Blanka");
		mntmBlanka.addActionListener(new MenuListener());
		mnNewMenu.add(mntmBlanka);
		
		JMenuItem mntmEHonda = new JMenuItem("E. Honda");
		mntmEHonda.addActionListener(new MenuListener());
		mnNewMenu.add(mntmEHonda);
		
		JMenuItem mntmDhalsim = new JMenuItem("Dhalsim");
		mntmDhalsim.addActionListener(new MenuListener());
		mnNewMenu.add(mntmDhalsim);
		
		JMenuItem mntmZangief = new JMenuItem("Zangief");
		mntmZangief.addActionListener(new MenuListener());
		mnNewMenu.add(mntmZangief);
		
		JMenu mnAdministrativeActions = new JMenu("Administrative Actions");
		menuBar.add(mnAdministrativeActions);
		
		JMenuItem mntmAddAction = new JMenuItem("Add Action");
		mntmAddAction.addActionListener(new AddJob());
		mnAdministrativeActions.add(mntmAddAction);
		
		JMenuItem mntmAddArtist = new JMenuItem("Add Artist");
		mntmAddArtist.addActionListener(new AddArtist());
		mnAdministrativeActions.add(mntmAddArtist);
		
		JMenuItem mntmCharacter = new JMenuItem("");
		menuBar.add(mntmCharacter);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.setBounds(10, 389, 89, 23);
		contentPane.add(btnNewButton);
		
		actionTypeSelect = new JComboBox();
		actionTypeSelect.setBounds(10, 285, 199, 20);
		actionTypeSelect.addActionListener(new ComboListener2());
		contentPane.add(actionTypeSelect);
		
		JLabel lblNewLabel = new JLabel("Select the category fo the action");
		lblNewLabel.setBounds(10, 251, 209, 23);
		contentPane.add(lblNewLabel);
		
		actionSelect = new JComboBox();
		actionSelect.setBounds(10, 355, 199, 23);
		actionSelect.addActionListener(new ComboListener3());
		contentPane.add(actionSelect);
		
		JLabel lblSelectTheSpecific = new JLabel("Select the specific action: ");
		lblSelectTheSpecific.setBounds(10, 333, 199, 14);
		contentPane.add(lblSelectTheSpecific);
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.setBounds(120, 389, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblTotalNumberOf = new JLabel("Total Number of Frames");
		lblTotalNumberOf.setBounds(10, 108, 130, 23);
		contentPane.add(lblTotalNumberOf);
		
		totalFrameCount = new JLabel("");
		totalFrameCount.setBounds(163, 112, 56, 20);
		contentPane.add(totalFrameCount);
		
		JLabel lblArtistsAssignedTo = new JLabel("Artists Assigned to Character: ");
		lblArtistsAssignedTo.setBounds(10, 142, 199, 23);
		contentPane.add(lblArtistsAssignedTo);
		
		artistSelect = new JComboBox();
		artistSelect.setBounds(10, 176, 199, 20);
		artistSelect.addActionListener(new ComboListener1());
		contentPane.add(artistSelect);
		
		JLabel lblNumberOfFrames = new JLabel("Number of Frames Completed/Total Number of Frames for Action: ");
		lblNumberOfFrames.setBounds(257, 255, 346, 20);
		contentPane.add(lblNumberOfFrames);
		
		framesComp = new JLabel("");
		framesComp.setBounds(613, 255, 110, 21);
		contentPane.add(framesComp);
		
		JLabel lblDeadline = new JLabel("Deadline");
		lblDeadline.setBounds(257, 287, 64, 17);
		contentPane.add(lblDeadline);
		
		deadline = new JLabel("");
		deadline.setBounds(613, 288, 110, 23);
		contentPane.add(deadline);
		
		JPanel panel = new JPanel();
		panel.setBounds(369, 11, 403, 223);
		contentPane.add(panel);
		
		charsName = new JLabel("");
		charsName.setHorizontalAlignment(SwingConstants.CENTER);
		charsName.setFont(new Font("Tahoma", Font.BOLD, 22));
		charsName.setBounds(10, 11, 199, 88);
		contentPane.add(charsName);
		
		dialog = new JDialog(frame, "Confirm new Artist");		
		dialog.setSize(480, 240);
		dialog.setLayout(new FlowLayout());
	}
	
	private void getCharID(String name) {
		/*Retrieves the charid when only the character name is known*/
		charid = 0;
		switch(name) {
		case "Ryu":
			charid = 1;
			break;
		case "Ken":
			charid = 2;
			break;
		case "Chun li":
			charid = 3;
			break;
		case "Guile":
			charid = 4;
			break;
		case "Blanka":
			charid = 5;
			break;
		case "E. Honda":
			charid = 6;
			break;
		case "Dhalsim":
			charid = 7;
			break;
		case "Zangief":
			charid=8;
			break;
		default: 
			System.out.println("Invalid name. Closing the program");
			System.exit(0);
			break;
		}
		
	}
	
	class MenuListener implements ActionListener {
		/*For the character menu. Displays total frames, character name, and list of artists when character
		 * is selected*/
		public void actionPerformed(ActionEvent e) {
			getCharID(e.getActionCommand());
			charsName.setText(e.getActionCommand());
			connect.updateTotalFrames(charid); //NEEDS IF STATEMENT
			totalFrameCount.setText(Integer.toString(connect.totalFrameCount));
	
			if(charid == 0) { 
				System.out.println("Error. Invalid CharID");
				System.exit(0);//Find method to exit program
			} else {
			artistSelect.setModel(new DefaultComboBoxModel(connect.getArtists(charid)));
			}
		}
	}
	
	class ComboListener1 implements ActionListener {
		/*Populates type action combo box upon selection of artist*/
		public void actionPerformed(ActionEvent e) {
			if (artistSelect.getSelectedItem() == "") { } 
			else {
				artistid = artistSelect.getSelectedIndex() + 41;
				actionTypeSelect.setModel(new DefaultComboBoxModel(connect.getTypeActions(artistid))); 
			}
		}
	}
	
	class ComboListener2 implements ActionListener {
		/*Populates action combo box upon selection of type of action*/
		public void actionPerformed(ActionEvent e) {
			if(actionTypeSelect.getSelectedItem().toString() == "") { }
			else {
				typeAction = actionTypeSelect.getSelectedItem().toString();
				actionSelect.setModel(new DefaultComboBoxModel(connect.getActions(typeAction, artistid)));
			}
		}
	}
	
	class ComboListener3 implements ActionListener {
		/*Updates frame data and deadline labels in GUI Window*/
		public void actionPerformed(ActionEvent e) {
			if (actionSelect.getSelectedItem().toString() == "") { }
			else {
				/*Updates public frame data fields in dbConnection.java*/
				connect.actionFrameData(charid, actionSelect.getSelectedItem().toString()); 
				framesComp.setText(Integer.toString(connect.actionFramesComp) + "/" + Integer.toString(connect.actionTotalFrames));
				deadline.setText(connect.deadline.toString());
			}
		}
	}
	
	class AddJob implements ActionListener {
		/*Front end code for adding new job. Pending Implementation*/
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "Feature not yet implemented");
		}
	}
	
	class AddArtist implements ActionListener {
		/*Adds artist*/
		public void actionPerformed(ActionEvent e) {
			lname = JOptionPane.showInputDialog("Please enter the artist's last name");
			fname = JOptionPane.showInputDialog("Please enter the artist's first name");
			
			JButton yes = new JButton("Yes");
			yes.addActionListener(new YesAction());
			JButton no = new JButton("No");
			no.addActionListener(new NoAction());
			
			JLabel Msg = new JLabel("You have entered the name " + fname + " " + lname + ". Are you sure this is correct?");
			dialog.add(Msg);
			dialog.add(yes);
			dialog.add(no);
			dialog.setVisible(true);
			
		}
	}
	
	class YesAction implements ActionListener {
		/*When Yes is clicked in Dialog Box*/
		public void actionPerformed(ActionEvent e) {
			connect.addArtist(lname,  fname);
			JOptionPane.showMessageDialog(null,  "Artist successfully added");
			dialog.dispose();
		}
	}
	
	class NoAction implements ActionListener {
		/*When no is clicked in Dialog Box*/
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "Process aborted. Please select \"Add Artist\" again to restart the process");
			dialog.dispose();
		}
	}
}
